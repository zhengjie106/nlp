import json
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.template.loader import render_to_string
#from app1.forms import settingForm
#from app1.Combined-audit-checking import auditCheck
# Create your views here.
import  app1.CombinedAuditChecking as cac
from keras.models import load_model
import numpy as np

#with open('/Users/liver/PycharmProjects/ML/AI1/app1/file/output.json') as d:
    #data = json.load(d)



def Output(request):
    data = []
    text = request.POST['desc']
    print(text)

    model = load_model('/Users/liver/PycharmProjects/ML/AI1/app1/models/general_result_pred_model.h5')
    #auditCheck(text)
    score1,msg1=cac.grammar_score(text)
    score2, msg2 = cac.similarity_check(text)
    score3,msg3 = cac.classification_check(text)
    score4, msg4 = cac.ner_extraction(text)

    predata = np.array([[round(score1, 2), round(score2, 2), round(score3, 2), round(score4, 2)]])
    result = model.predict(predata)

    totals = result[0][0] * 100



    result={}
    result['Name']=msg1
    result['ID'] = score1*5
    data.append(result)

    result = {}
    result['Name'] = msg2
    result['ID'] = score2*20
    data.append(result)

    result = {}
    result['Name'] = msg3
    result['ID'] = score3*40
    data.append(result)

    result = {}
    result['Name'] = msg4
    result['ID'] = score4*35
    data.append(result)

    finalScore=totals
    resultmsg=''
    if finalScore>70:
        resultmsg='Good'
    else:
        resultmsg='Bad'
    result = {}
    result['Name'] = 'General result: {}'.format(resultmsg)
    result['ID'] = totals
    data.append(result)

    return render(request, 'output.html', {'d': data})


def Input(request):
        return render(request, 'input.html')


def Config(request):
    with open('/Users/liver/PycharmProjects/ML/AI1/app1/file/config.json', 'r+') as c:
        configData = json.load(c)
        if request.method == 'POST':
            for k in configData:
                text1 = "weight " + k['Component']
                text2 = "confidence " + k['Component']
                weight = request.POST[text1]
                k['Weight'] = weight
                if not k['Confidence'] is None:
                    confidence = request.POST[text2]
                    k['Confidence'] = confidence
            c.seek(0)
            c.write(json.dumps(configData))
            c.truncate()
            return redirect('/')
        else:
            print(configData)
            return render(request, 'setting.html', {'c': configData})
