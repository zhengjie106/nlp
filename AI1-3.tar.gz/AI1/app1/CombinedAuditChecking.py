# coding: utf-8

# # 1. check the grammar: 

# In[6]:


import language_check
import spacy
from nltk.tokenize import word_tokenize
import json


def grammar_score(doc):
    lc_tool = language_check.LanguageTool('en-US')

    matchs = lc_tool.check(doc)

    mCount = len(matchs)
    word_cnt = len(word_tokenize(doc))

    score = 0
    if mCount >= 5:
        score = 0
    else:
        score = (word_cnt - mCount) / word_cnt
    errorlist = []
    error = {}
    for t in matchs:
        errorlist.append(str(t))

    msg = 'This paragraph contains at lest {} program errors: \n{}'.format(len(matchs), '-'.join(errorlist))
    return (score, msg)


# In[19]:


def similarity_check(doc):
    text = doc.lower()
    word_cnt = len(word_tokenize(text))
    with open('/Users/liver/PycharmProjects/ML/AI1/app1/models/population1_1.json') as f:
        data = json.load(f)
    match_cnt = 0
    keywords = {}
    for example in data['rasa_nlu_data']['common_examples']:
        ents = {}
        entlist = []
        for entitem in example['entities']:
            t = entitem['value']
            key = entitem['entity']
            if text.find(t.lower()) >= 0:
                # match
                match_cnt = match_cnt + 1
                if key in keywords:
                    valuelist = keywords.get(key)
                    valuelist.append(t)
                else:
                    valuelist = []
                    valuelist.append(t)
                    keywords[key] = valuelist
    for k in keywords.keys():
        s = set(keywords[k])
        keywords[k] = s

    y = 0
    if 'source_data' in keywords:
        y = y + 0.3
    if 'frequency' in keywords:
        y = y + 0.4
    if 'control_verb' in keywords:
        y = y + 0.3

    return (y, str(keywords))





def classification_check(doc):
    modelpath = '/Users/liver/PycharmProjects/ML/AI1/app1/models/audit-classification-pop1-model'

    # print("Loading from", modelpath)
    nlp2 = spacy.load(modelpath)
    doc2 = nlp2(doc)
    # print(doc2.cats['POSITIVE'],'The paragraph is classified as good in the confidence level of {}'.format(doc2.cats['POSITIVE']))
    return (doc2.cats['POSITIVE'],
            'The paragraph is classified as good in the confidence level of {}'.format(doc2.cats['POSITIVE']))




def ner_extraction(doc):
    output_dir = '/Users/liver/PycharmProjects/ML/AI1/app1/models/audit-pop1-ner-train'
    nlp2 = spacy.load(output_dir)
    doc = nlp2(doc)
    # ents=[(ent.text, ent.label_) for ent in doc.ents]
    entlist = {}

    for ent in doc.ents:
        txt = ent.text
        lab = ent.label_
        if lab in entlist:
            valuelist = entlist.get(lab)
            valuelist.append(txt)
        else:
            valuelist = []
            valuelist.append(txt)
            entlist[lab] = valuelist
    # generate score
    iScore = 0
    y = 0
    if ('source_data' in entlist) or ('Describe_source_data' in entlist):
        y = y + 0.5
    if 'frequency' in entlist:
        y = y + 0.7
    if ('control_verb' in entlist) or ('valid population_control_verb' in entlist):
        y = y + 0.5

    return (y, "entitiys are found in {} type(s):{}".format(len(entlist), str(entlist)))







