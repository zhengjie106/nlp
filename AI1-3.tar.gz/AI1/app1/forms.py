from django import forms


class settingForm(forms.Form):
    post = forms.CharField()